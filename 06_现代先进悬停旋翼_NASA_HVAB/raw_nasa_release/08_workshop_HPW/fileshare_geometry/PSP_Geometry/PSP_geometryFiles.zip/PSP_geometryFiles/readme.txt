**** STRUCTURED GRID ***

File: blade_structured.plot3d
Format: unformatted, double precision, multi-grid, no iblank, plot3d

There are three overset surface grids:

(1) main blade grid
(2) root cap grid
(3) tip cap grid

The volume grid is also available upon request.

**** UNSTRUCTURED GRID ***

The unstructured surface grid is provided in three formats:

(1) File: blade_unstructured.nas
    Format: formatted (ASCII), NASTRAN

(2) File: blade_unstructured.r8.ugrid
    Format: Unformatted, double precision, UGRID

(3) File: blade_unstructured.fvuns
    Format: Unformatted, double precision, Fieldview

The volume grid is also available upon request.

Rohit Jain
US Army Aviation Development Directorate (ADD)
650-604-3697
rohit.k.jain.civ@mail.mil
